const productWrap = document.getElementById("productWrap");
const categoryFilter = document.getElementById("categoryFilter");
const brandFilter = document.getElementById("brandFilter");
const resultInfo = document.getElementById("resultInfo");
const emptyState = document.getElementById("emptyState");

function productCard(p) {
  return `
    <div class="bg-white dark:bg-gray-900 border dark:border-gray-800 rounded-3xl shadow p-4 hover:shadow-md transition">
      <a href="/product-details/?id=${p.id}">
        <img src="${p.image}" class="w-full h-44 object-cover rounded-2xl" />
      </a>

      <div class="mt-3">
        <h3 class="font-semibold text-lg">${p.title}</h3>

        <div class="flex items-center justify-between mt-2">
          <div>
            <p class="text-xs text-gray-400 line-through">$${p.price}</p>
            <p class="text-indigo-600 font-bold text-lg">$${p.discount_price}</p>
          </div>
          <span class="text-xs bg-yellow-100 px-2 py-1 rounded-xl text-black">⭐ ${p.star}</span>
        </div>

        <a href="/product-details/?id=${p.id}"
          class="block mt-4 text-center bg-gray-900 hover:bg-black text-white py-2 rounded-2xl font-semibold">
          View Details
        </a>
      </div>
    </div>
  `;
}

function setEmpty(show) {
  emptyState.classList.toggle("hidden", !show);
}

function qs() {
  return new URLSearchParams(window.location.search);
}

function go(paramsObj) {
  const params = new URLSearchParams(paramsObj);
  window.location.href = `/product/?${params.toString()}`;
}

async function loadFilters() {
  const categories = await apiGet("categories/");
  categoryFilter.innerHTML = (categories.data || []).map((c) => `
    <button class="w-full text-left px-3 py-2 rounded-2xl bg-gray-50 hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700"
      onclick="location.href='/product/?category=${c.id}'">
      ${c.categoryName}
    </button>
  `).join("");

  const brands = await apiGet("brands/");
  brandFilter.innerHTML = (brands.data || []).map((b) => `
    <button class="w-full text-left px-3 py-2 rounded-2xl bg-gray-50 hover:bg-gray-100 dark:bg-gray-800 dark:hover:bg-gray-700"
      onclick="location.href='/product/?brand=${b.id}'">
      ${b.brandName}
    </button>
  `).join("");
}

async function loadProducts() {
  initNavbarAuth();

  const params = qs();
  const remark = params.get("remark");
  const category = params.get("category");
  const brand = params.get("brand");
  const search = params.get("search");

  let endpoint = "products/remark/popular/";

  if (remark) endpoint = `products/remark/${remark}/`;
  else if (category) endpoint = `products/category/${category}/`;
  else if (brand) endpoint = `products/brand/${brand}/`;
  else if (search) endpoint = `products/search/?keyword=${encodeURIComponent(search)}`;

  const res = await apiGet(endpoint);

  const products = res.data || [];

  if (!res.status || products.length === 0) {
    productWrap.innerHTML = "";
    setEmpty(true);
    resultInfo.innerText = "0 items";
    return;
  }

  setEmpty(false);
  resultInfo.innerText = `${products.length} items`;
  productWrap.innerHTML = products.map(productCard).join("");
}

function initSearchBar() {
  const searchInput = document.getElementById("searchInput");
  const searchBtn = document.getElementById("searchBtn");

  const searchInputM = document.getElementById("searchInputM");
  const searchBtnM = document.getElementById("searchBtnM");

  function doSearch(q) {
    if (!q) return;
    go({ search: q });
  }

  if (searchBtn) searchBtn.addEventListener("click", () => doSearch(searchInput.value.trim()));
  if (searchBtnM) searchBtnM.addEventListener("click", () => doSearch(searchInputM.value.trim()));
}

function initRemarkButtons() {
  document.querySelectorAll(".remarkBtn").forEach(btn => {
    btn.addEventListener("click", () => {
      go({ remark: btn.dataset.remark });
    });
  });
}

document.getElementById("clearFilters").addEventListener("click", () => {
  window.location.href = "/product/";
});

initSearchBar();
initRemarkButtons();
loadFilters();
loadProducts();
