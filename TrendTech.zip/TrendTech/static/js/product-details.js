const detailsWrap = document.getElementById("detailsWrap");

function qs() {
  return new URLSearchParams(window.location.search);
}

function toOptions(csvText) {
  if (!csvText) return [];
  return csvText.split(",").map((s) => s.trim()).filter(Boolean);
}

async function loadDetails() {
  initNavbarAuth();

  const id = qs().get("id");
  if (!id) {
    detailsWrap.innerHTML = `<p class="text-red-600 font-semibold">Product ID missing!</p>`;
    return;
  }

  const res = await apiGet(`products/${id}/`);
  if (!res.status) {
    detailsWrap.innerHTML = `<p class="text-red-600 font-semibold">${res.message || "Failed to load details"}</p>`;
    return;
  }

  const product = res.data.product;
  const details = res.data.details;

  const colors = toOptions(details.color);
  const sizes = toOptions(details.size);

  detailsWrap.innerHTML = `
    <div class="grid lg:grid-cols-2 gap-8 items-start">
      
      <div>
        <img id="mainImg" src="${details.img1}" class="w-full h-[340px] object-cover rounded-3xl border dark:border-gray-800" />
        <div class="grid grid-cols-4 gap-3 mt-4">
          ${[details.img1, details.img2, details.img3, details.img4]
            .map(
              (img) => `
              <img src="${img}"
                class="thumb w-full h-20 object-cover rounded-2xl cursor-pointer border dark:border-gray-700 hover:border-indigo-600"/>
            `
            )
            .join("")}
        </div>
      </div>

      <div>
        <p class="text-sm text-indigo-500 font-semibold uppercase">${product.remark}</p>
        <h1 class="text-3xl font-bold mt-1">${product.title}</h1>
        <p class="text-gray-600 dark:text-gray-300 mt-2">${product.short_des}</p>

        <div class="mt-4 flex items-center gap-3">
          <span class="text-2xl font-bold text-indigo-500">$${product.discount_price}</span>
          <span class="text-gray-400 line-through">$${product.price}</span>
          <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-xl">${product.discount}% OFF</span>
        </div>

        <div class="mt-3 text-sm bg-yellow-100 inline-block px-3 py-1 rounded-xl text-black">
          ⭐ ${product.star} rating
        </div>

        <div class="mt-6">
          <h3 class="font-semibold">Description</h3>
          <p class="text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">${details.des}</p>
        </div>

        <div class="mt-6 grid sm:grid-cols-2 gap-4">
          <div>
            <label class="text-sm font-semibold">Color</label>
            <select id="colorSelect" class="w-full border dark:border-gray-700 dark:bg-gray-800 rounded-2xl px-4 py-2 mt-1">
              ${colors.map((c) => `<option value="${c}">${c}</option>`).join("")}
            </select>
          </div>

          <div>
            <label class="text-sm font-semibold">Size</label>
            <select id="sizeSelect" class="w-full border dark:border-gray-700 dark:bg-gray-800 rounded-2xl px-4 py-2 mt-1">
              ${sizes.map((s) => `<option value="${s}">${s}</option>`).join("")}
            </select>
          </div>
        </div>

        <div class="mt-6 flex gap-3">
          <button id="addCartBtn"
            class="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-2xl font-semibold">
            Add to Cart
          </button>

          <!-- ✅ Wishlist Heart Button -->
          <button id="wishBtn"
            class="w-14 h-14 rounded-2xl border dark:border-gray-700 bg-white dark:bg-gray-800 hover:scale-[1.03] transition grid place-items-center text-2xl">
            🤍
          </button>
        </div>

        <p id="msg" class="mt-4 text-sm font-semibold"></p>
      </div>
    </div>
  `;

  // ✅ Gallery thumb click
  document.querySelectorAll(".thumb").forEach((t) => {
    t.addEventListener("click", () => {
      document.getElementById("mainImg").src = t.src;
    });
  });

  const msg = document.getElementById("msg");
  const wishBtn = document.getElementById("wishBtn");

  // ✅ Add to cart
  document.getElementById("addCartBtn").addEventListener("click", async () => {
    if (!isLoggedIn()) {
      msg.innerText = "⚠ Please login first!";
      msg.className = "mt-4 text-sm font-semibold text-red-500";
      return;
    }

    const color = document.getElementById("colorSelect").value || "";
    const size = document.getElementById("sizeSelect").value || "";

    const body = { product_id: parseInt(id), color, size, qty: "1" };
    const r = await apiPost("cart/add/", body, true);

    if (r.status) {
      msg.innerText = "✅ Added to cart!";
      msg.className = "mt-4 text-sm font-semibold text-green-500";
    } else {
      msg.innerText = r.message || "❌ Failed to add cart!";
      msg.className = "mt-4 text-sm font-semibold text-red-500";
    }
  });

  // ✅ Wishlist toggle (heart red) + call API
  wishBtn.addEventListener("click", async () => {
    if (!isLoggedIn()) {
      msg.innerText = "⚠ Please login first!";
      msg.className = "mt-4 text-sm font-semibold text-red-500";
      return;
    }

    // UI instant feedback
    wishBtn.innerHTML = "❤️";

    const r = await apiPost("wish/add/", { product_id: parseInt(id) }, true);

    if (r.status) {
      msg.innerText = "✅ Added to wishlist!";
      msg.className = "mt-4 text-sm font-semibold text-green-500";
    } else {
      // if already exists
      msg.innerText = r.message || "❌ Failed to wishlist!";
      msg.className = "mt-4 text-sm font-semibold text-red-500";

      // if failed revert heart
      if (!r.status) wishBtn.innerHTML = "🤍";
    }
  });
}

loadDetails();
