const msg = document.getElementById("msg");
const picMsg = document.getElementById("picMsg");

const profilePicPreview = document.getElementById("profilePicPreview");
const profilePicInput = document.getElementById("profilePicInput");
const savePicBtn = document.getElementById("savePicBtn");

const logoutBtn = document.getElementById("logoutBtn");
const profileForm = document.getElementById("profileForm");
const userEmailText = document.getElementById("userEmailText");

function setStatus(el, text, ok = true) {
  el.innerText = text;
  el.className = ok
    ? "text-sm mt-3 text-green-400 font-semibold"
    : "text-sm mt-3 text-red-400 font-semibold";
}

function requireLogin() {
  if (!getToken()) {
    alert("Please login first!");
    window.location.href = "/login/";
    return false;
  }
  return true;
}

async function loadProfile() {
  if (!requireLogin()) return;

  userEmailText.innerText = "";

  const res = await apiGet("profile/", true);

  if (!res.status) {
    setStatus(msg, "❌ Failed to load profile!", false);
    return;
  }

  if (!res.data) {
    setStatus(msg, "No profile found. Fill the form and save ✅", true);
    return;
  }

  const p = res.data;

  // set inputs
  [
    "cus_name","cus_add","cus_city","cus_state","cus_postcode","cus_country","cus_phone","cus_fax",
    "ship_name","ship_add","ship_city","ship_state","ship_postcode","ship_country","ship_phone"
  ].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = p[id] || "";
  });

  // profile pic
  if (p.profile_pic_url) {
    profilePicPreview.src = p.profile_pic_url;
  }
}

// ✅ One function for updating profile (text + optional photo)
async function updateProfileWithFormData(includePhoto = false) {
  if (!requireLogin()) return;

  const formData = new FormData();

  // text fields
  [
    "cus_name","cus_add","cus_city","cus_state","cus_postcode","cus_country","cus_phone","cus_fax",
    "ship_name","ship_add","ship_city","ship_state","ship_postcode","ship_country","ship_phone"
  ].forEach((id) => {
    const v = document.getElementById(id).value.trim();
    formData.append(id, v);
  });

  // photo (optional)
  if (includePhoto) {
    const file = profilePicInput.files[0];
    if (!file) {
      setStatus(picMsg, "❌ Please select an image!", false);
      return;
    }
    formData.append("profile_pic", file);
  }

  const res = await fetch(`${BASE_URL}profile/update/`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getToken()}`, // ✅ token only
      // ❌ DO NOT set Content-Type here
    },
    body: formData,
  });

  const data = await res.json();

  if (data.status) {
    if (includePhoto) {
      setStatus(picMsg, "✅ Photo updated!", true);
    } else {
      setStatus(msg, "✅ Profile saved successfully!", true);
    }

    if (data.data?.profile_pic_url) {
      profilePicPreview.src = data.data.profile_pic_url;
    }
  } else {
    if (includePhoto) {
      setStatus(picMsg, data.message || "❌ Failed to upload photo", false);
    } else {
      setStatus(msg, data.message || "❌ Failed to save profile", false);
    }
  }
}

// ✅ form submit => save profile text
profileForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setStatus(msg, "Saving profile...", true);
  await updateProfileWithFormData(false);
});

// ✅ Save Photo btn => save profile + photo together
savePicBtn.addEventListener("click", async () => {
  setStatus(picMsg, "Uploading photo...", true);
  await updateProfileWithFormData(true);
});

// preview selected pic instantly
profilePicInput.addEventListener("change", () => {
  const file = profilePicInput.files[0];
  if (!file) return;
  profilePicPreview.src = URL.createObjectURL(file);
});

logoutBtn.addEventListener("click", () => {
  logout();
});

loadProfile();
