const wishWrap = document.getElementById("wishWrap");
const emptyWish = document.getElementById("emptyWish");

function wishCard(item) {
  return `
    <div class="bg-gray-50 dark:bg-gray-800 border dark:border-gray-700 rounded-3xl p-4">
      <a href="/product-details/?id=${item.product_id}">
        <img src="${item.product_image}" class="w-full h-44 object-cover rounded-2xl" />
      </a>

      <h3 class="mt-3 font-semibold text-lg">${item.product_title}</h3>

      <div class="mt-2 flex items-center justify-between">
        <div>
          <p class="text-xs text-gray-400 line-through">$${item.product_price}</p>
          <p class="text-indigo-600 font-bold">$${item.product_discount_price}</p>
        </div>
        <span class="text-xs bg-yellow-100 px-2 py-1 rounded-xl text-black">⭐ ${item.product_star}</span>
      </div>

      <div class="mt-4 flex gap-2">
        <a href="/product-details/?id=${item.product_id}"
          class="flex-1 text-center bg-gray-900 hover:bg-black text-white py-2 rounded-2xl font-semibold">
          View
        </a>

        <button onclick="removeWish(${item.id})"
          class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-2xl">
          Remove
        </button>
      </div>
    </div>
  `;
}

async function removeWish(wishId) {
  await apiDelete(`wish/remove/${wishId}/`, true);
  loadWish();
}

async function loadWish() {
  initNavbarAuth();

  if (!isLoggedIn()) {
    wishWrap.innerHTML = "";
    emptyWish.classList.remove("hidden");
    emptyWish.innerHTML = `
      <h3 class="text-xl font-bold">Please login first</h3>
      <p class="text-gray-500 dark:text-gray-400 mt-2">Login to view your wishlist.</p>
    `;
    return;
  }

  const res = await apiGet("wish/list/", true);
  const items = res.data || [];

  if (items.length === 0) {
    wishWrap.innerHTML = "";
    emptyWish.classList.remove("hidden");
    return;
  }

  emptyWish.classList.add("hidden");
  wishWrap.innerHTML = items.map(wishCard).join("");
}

loadWish();
