document.getElementById("year").innerText = new Date().getFullYear();

const sliderWrap = document.getElementById("sliderWrap");
const popularWrap = document.getElementById("popularWrap");
const categoryCarouselBox = document.getElementById("categoryCarouselBox");
const categoryCarousel = document.getElementById("categoryCarousel");
const allCategoryGrid = document.getElementById("allCategoryGrid");
const toggleCategoryBtn = document.getElementById("toggleCategoryBtn");
const brandCarouselBox = document.getElementById("brandCarouselBox");
const brandCarousel = document.getElementById("brandCarousel");
const allBrandGrid = document.getElementById("allBrandGrid");
const toggleBrandBtn = document.getElementById("toggleBrandBtn");

// ===== Carousel State =====
let catScrollX = 0;
let catPaused = false;
let catSpeed = 0.6; // ✅ speed
let catRAF = null;

// swipe state
let isDragging = false;
let startX = 0;
let lastX = 0;

// Brand carousel state
let brandScrollX = 0;
let brandPaused = false;
let brandSpeed = 0.6;
let brandRAF = null;

// swipe state
let brandDragging = false;
let brandLastX = 0;

function sliderCard(item) {
  return `
    <a href="/product-details/?id=${item.product}"
      class="group flex items-center gap-4 bg-white border border-gray-200 hover:border-indigo-400
             rounded-2xl p-4 transition shadow-sm hover:shadow-md">

      <img src="${item.image}"
        class="w-20 h-20 rounded-2xl object-cover border border-gray-200" />

      <div class="flex-1 min-w-0">
        <p class="text-sm font-bold text-gray-900 group-hover:text-indigo-600 truncate">
          ${item.title}
        </p>

        <p class="text-xs text-gray-600 mt-1 line-clamp-2">
          ${item.short_des}
        </p>

        <div class="mt-2 flex items-center justify-between">
          <span class="text-indigo-600 font-bold text-lg">
            $${item.price}
          </span>

          <span class="text-xs font-semibold bg-indigo-50 text-indigo-700 px-3 py-1 rounded-xl border border-indigo-100">
            View →
          </span>
        </div>
      </div>
    </a>
  `;
}

function brandCard(b) {
  return `
    <a href="/product/?brand=${b.id}"
      class="min-w-[260px] md:min-w-[280px] bg-white rounded-3xl shadow p-4 hover:shadow-md transition">
      <img src="${b.brandImg}" class="w-full h-28 rounded-2xl object-cover" />
      <h4 class="mt-3 font-semibold text-gray-900 text-base truncate">
        ${b.brandName}
      </h4>
      <p class="text-xs text-gray-500 mt-1">Explore products →</p>
    </a>
  `;
}

function brandGridCard(b) {
  return `
    <a href="/product/?brand=${b.id}"
      class="bg-white rounded-3xl shadow p-4 hover:shadow-md transition">
      <img src="${b.brandImg}" class="w-full h-28 rounded-2xl object-cover" />
      <h4 class="mt-3 font-semibold text-gray-900 truncate">${b.brandName}</h4>
      <p class="text-xs text-gray-500 mt-1">Explore products →</p>
    </a>
  `;
}

function startBrandAutoScroll() {
  if (!brandCarousel) return;

  function animate() {
    if (!brandPaused && !brandDragging) {
      brandScrollX += brandSpeed;
      brandCarousel.style.transform = `translateX(-${brandScrollX}px)`;

      if (brandScrollX >= brandCarousel.scrollWidth / 2) {
        brandScrollX = 0;
      }
    }

    brandRAF = requestAnimationFrame(animate);
  }

  cancelAnimationFrame(brandRAF);
  brandRAF = requestAnimationFrame(animate);
}

function initBrandHoverPause() {
  if (!brandCarouselBox) return;

  brandCarouselBox.addEventListener("mouseenter", () => {
    brandPaused = true;
  });

  brandCarouselBox.addEventListener("mouseleave", () => {
    brandPaused = false;
  });
}

function initBrandSwipe() {
  if (!brandCarouselBox) return;

  // touch
  brandCarouselBox.addEventListener("touchstart", (e) => {
    brandDragging = true;
    brandPaused = true;
    brandLastX = e.touches[0].clientX;
  });

  brandCarouselBox.addEventListener("touchmove", (e) => {
    if (!brandDragging) return;
    const x = e.touches[0].clientX;
    const dx = brandLastX - x;
    brandScrollX += dx;
    brandLastX = x;

    if (brandScrollX < 0) brandScrollX = 0;
    brandCarousel.style.transform = `translateX(-${brandScrollX}px)`;
  });

  brandCarouselBox.addEventListener("touchend", () => {
    brandDragging = false;
    brandPaused = false;
  });

  // mouse drag
  brandCarouselBox.addEventListener("mousedown", (e) => {
    brandDragging = true;
    brandPaused = true;
    brandLastX = e.clientX;
  });

  brandCarouselBox.addEventListener("mousemove", (e) => {
    if (!brandDragging) return;
    const x = e.clientX;
    const dx = brandLastX - x;
    brandScrollX += dx;
    brandLastX = x;

    if (brandScrollX < 0) brandScrollX = 0;
    brandCarousel.style.transform = `translateX(-${brandScrollX}px)`;
  });

  brandCarouselBox.addEventListener("mouseup", () => {
    brandDragging = false;
    brandPaused = false;
  });

  brandCarouselBox.addEventListener("mouseleave", () => {
    brandDragging = false;
    brandPaused = false;
  });
}

function categoryCard(c) {
  return `
    <a href="/product/?category=${c.id}"
      class="min-w-[260px] md:min-w-[280px] bg-white rounded-3xl shadow p-4 hover:shadow-md transition">
      <img src="${c.categoryImg}" class="w-full h-28 rounded-2xl object-cover" />
      <h4 class="mt-3 font-semibold text-gray-900 text-base truncate">
        ${c.categoryName}
      </h4>
      <p class="text-xs text-gray-500 mt-1">Explore products →</p>
    </a>
  `;
}

function categoryGridCard(c) {
  return `
    <a href="/product/?category=${c.id}"
      class="bg-white rounded-3xl shadow p-4 hover:shadow-md transition">
      <img src="${c.categoryImg}" class="w-full h-28 rounded-2xl object-cover" />
      <h4 class="mt-3 font-semibold text-gray-900 truncate">${c.categoryName}</h4>
      <p class="text-xs text-gray-500 mt-1">Explore products →</p>
    </a>
  `;
}

function startCategoryAutoScroll() {
  if (!categoryCarousel) return;

  function animate() {
    if (!catPaused && !isDragging) {
      catScrollX += catSpeed;
      categoryCarousel.style.transform = `translateX(-${catScrollX}px)`;

      // reset loop (half width because duplicated list)
      if (catScrollX >= categoryCarousel.scrollWidth / 2) {
        catScrollX = 0;
      }
    }

    catRAF = requestAnimationFrame(animate);
  }

  cancelAnimationFrame(catRAF);
  catRAF = requestAnimationFrame(animate);
}

// Pause on hover (desktop)
function initCategoryHoverPause() {
  if (!categoryCarouselBox) return;

  categoryCarouselBox.addEventListener("mouseenter", () => {
    catPaused = true;
  });

  categoryCarouselBox.addEventListener("mouseleave", () => {
    catPaused = false;
  });
}

// Mobile swipe / drag support
function initCategorySwipe() {
  if (!categoryCarouselBox) return;

  // touch start
  categoryCarouselBox.addEventListener("touchstart", (e) => {
    isDragging = true;
    catPaused = true;
    startX = e.touches[0].clientX;
    lastX = startX;
  });

  categoryCarouselBox.addEventListener("touchmove", (e) => {
    if (!isDragging) return;
    const x = e.touches[0].clientX;
    const dx = lastX - x;
    catScrollX += dx;
    lastX = x;

    if (catScrollX < 0) catScrollX = 0;
    categoryCarousel.style.transform = `translateX(-${catScrollX}px)`;
  });

  categoryCarouselBox.addEventListener("touchend", () => {
    isDragging = false;
    catPaused = false;
  });

  // mouse drag (desktop optional)
  categoryCarouselBox.addEventListener("mousedown", (e) => {
    isDragging = true;
    catPaused = true;
    startX = e.clientX;
    lastX = startX;
  });

  categoryCarouselBox.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    const x = e.clientX;
    const dx = lastX - x;
    catScrollX += dx;
    lastX = x;

    if (catScrollX < 0) catScrollX = 0;
    categoryCarousel.style.transform = `translateX(-${catScrollX}px)`;
  });

  categoryCarouselBox.addEventListener("mouseup", () => {
    isDragging = false;
    catPaused = false;
  });

  categoryCarouselBox.addEventListener("mouseleave", () => {
    isDragging = false;
    catPaused = false;
  });
}

function productCard(p) {
  return `
    <div class="bg-white rounded-3xl shadow p-4 hover:shadow-md transition">
      <a href="/product-details/?id=${p.id}">
        <img src="${p.image}" class="w-full h-44 object-cover rounded-2xl" />
      </a>

      <h3 class="mt-3 font-bold text-lg text-gray-900 truncate">
        ${p.title}
      </h3>

      <div class="flex items-center justify-between mt-2">
        <div>
          <p class="text-xs text-gray-400 line-through">$${p.price}</p>
          <p class="text-indigo-600 font-bold text-lg">$${p.discount_price}</p>
        </div>

        <!-- Rating Text Black -->
        <span class="text-xs bg-yellow-100 text-black px-3 py-1 rounded-xl font-semibold">
          ⭐ ${p.star}
        </span>
      </div>

      <a href="/product-details/?id=${p.id}"
        class="block mt-4 text-center bg-gray-900 hover:bg-black text-white py-2 rounded-2xl font-semibold">
        View Details
      </a>
    </div>
  `;
}

async function loadBrands() {
  const res = await apiGet("brands/");
  const brands = res.data || [];

  brandCarousel.innerHTML = brands.map(brandCard).join("") + brands.map(brandCard).join("");
  allBrandGrid.innerHTML = brands.map(brandGridCard).join("");

  initBrandHoverPause();
  initBrandSwipe();
  startBrandAutoScroll();
}

let showAllBrands = false;

toggleBrandBtn.addEventListener("click", () => {
  showAllBrands = !showAllBrands;

  if (showAllBrands) {
    allBrandGrid.classList.remove("hidden");
    toggleBrandBtn.innerText = " ⌃ ";
  } else {
    allBrandGrid.classList.add("hidden");
    toggleBrandBtn.innerText = " ⌄ ";
  }
});

async function loadCategories() {
  const catRes = await apiGet("categories/");
  const categories = catRes.data || [];

  // Carousel shows all categories (duplicated for infinite loop)
  categoryCarousel.innerHTML = categories.map(categoryCard).join("") + categories.map(categoryCard).join("");

  // All categories grid for "View More"
  allCategoryGrid.innerHTML = categories.map(categoryGridCard).join("");

  // Start effects
  initCategoryHoverPause();
  initCategorySwipe();
  startCategoryAutoScroll();
}

let showAllCategories = false;

toggleCategoryBtn.addEventListener("click", () => {
  showAllCategories = !showAllCategories;

  if (showAllCategories) {
    allCategoryGrid.classList.remove("hidden");
    toggleCategoryBtn.innerText = " ⌃ ";
  } else {
    allCategoryGrid.classList.add("hidden");
    toggleCategoryBtn.innerText = " ⌄ ";
  }
});

async function loadHome() {
  initNavbarAuth();

  const sliderRes = await apiGet("products/sliders/");
  sliderWrap.innerHTML = sliderRes.data.slice(0, 6).map(sliderCard).join("");

  await loadBrands();
  await loadCategories();

  const popRes = await apiGet("products/remark/popular/");
  popularWrap.innerHTML = popRes.data.map(productCard).join("");
}

function initSearch() {
  const searchInput = document.getElementById("searchInput");
  const searchBtn = document.getElementById("searchBtn");

  const searchInputM = document.getElementById("searchInputM");
  const searchBtnM = document.getElementById("searchBtnM");

  function goSearch(q) {
    window.location.href = `/product/?search=${encodeURIComponent(q)}`;
  }

  if (searchBtn) searchBtn.addEventListener("click", () => goSearch(searchInput.value.trim()));
  if (searchBtnM) searchBtnM.addEventListener("click", () => goSearch(searchInputM.value.trim()));
}

initSearch();
loadHome();
