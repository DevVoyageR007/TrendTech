function closeProfileMenu() {
  const menu = document.getElementById("profileMenu");
  if (menu) menu.classList.add("hidden");
}

function getEmailFromToken() {
  try {
    const token = getToken();
    if (!token) return "";
    const payload = JSON.parse(atob(token.split(".")[1]));
    return payload.user_email || "";
  } catch (e) {
    return "";
  }
}

function setDropdownEmail() {
  const userEmailText = document.getElementById("userEmailText");
  if (!userEmailText) return;

  const email = getEmailFromToken();
  userEmailText.innerText = email ? email : "Logged in";
}

async function loadNavbarAvatar() {
  const avatarImg = document.getElementById("avatarImg");
  const avatarLetter = document.getElementById("avatarLetter");

  // if elements not exist, skip
  if (!avatarImg || !avatarLetter) return;

  // not logged in
  if (!getToken()) {
    avatarImg.classList.add("hidden");
    avatarLetter.classList.remove("hidden");
    avatarLetter.innerText = "U";
    return;
  }

  try {
    const res = await apiGet("profile/", true);
    const pic = res?.data?.profile_pic_url;

    if (pic) {
      const fullUrl = pic.startsWith("http")
        ? pic
        : `${BASE_URL.replace(/\/$/, "")}${pic}`;

      avatarImg.src = fullUrl;
      avatarImg.classList.remove("hidden");
      avatarLetter.classList.add("hidden");
    } else {
      avatarImg.classList.add("hidden");
      avatarLetter.classList.remove("hidden");
      avatarLetter.innerText = "U";
    }
  } catch (err) {
    avatarImg.classList.add("hidden");
    avatarLetter.classList.remove("hidden");
    avatarLetter.innerText = "U";
  }
}

function initNavbarAuth() {
  const navRight = document.getElementById("navRight");
  if (!navRight) return;

  // NOT logged in
  if (!getToken()) {
    navRight.innerHTML = `
      <a href="/login/" class="px-4 py-2 rounded-2xl bg-gray-900 text-white hover:bg-black">
        Login
      </a>
    `;
    return;
  }

  // logged in
  navRight.innerHTML = `
    <a href="/wish/" class="px-4 py-2 rounded-2xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700">
      Wishlist
    </a>
    <a href="/cart/" class="px-4 py-2 rounded-2xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700">
      Cart
    </a>

    <!-- ✅ Avatar Button -->
    <button id="profileBtn"
      class="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold grid place-items-center overflow-hidden border border-white/10">
      
      <span id="avatarLetter">U</span>
      <img id="avatarImg" src="" class="hidden w-full h-full object-cover" alt="Avatar"/>
    </button>
  `;

  // dropdown open/close
  const profileBtn = document.getElementById("profileBtn");
  const menu = document.getElementById("profileMenu");

  if (profileBtn && menu) {
    profileBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      menu.classList.toggle("hidden");
    });
  }

  // email set in dropdown
  setDropdownEmail();

  // logout button
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.onclick = (e) => {
      e.stopPropagation();
      logout();
    };
  }

  // outside click close menu
  document.addEventListener("click", () => closeProfileMenu());

  // load avatar image
  loadNavbarAvatar();
}

// Auto run on every page that loads ui.js
document.addEventListener("DOMContentLoaded", () => {
  initNavbarAuth();
});
