const cartWrap = document.getElementById("cartWrap");
const emptyCart = document.getElementById("emptyCart");

const subtotalEl = document.getElementById("subtotal");
const vatEl = document.getElementById("vat");
const totalEl = document.getElementById("total");

const cusDetails = document.getElementById("cusDetails");
const shipDetails = document.getElementById("shipDetails");
const checkoutBtn = document.getElementById("checkoutBtn");

const cartMsg = document.getElementById("cartMsg");
const addressNote = document.getElementById("addressNote");

function money(n) {
  return `$${Number(n).toFixed(2)}`;
}

function cartItemCard(item) {
  return `
    <div class="flex gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border dark:border-gray-700">
      <img src="${item.product_image}" class="w-20 h-20 rounded-2xl object-cover"/>

      <div class="flex-1">
        <h3 class="font-semibold text-base">${item.product_title}</h3>

        <p class="text-sm text-gray-600 dark:text-gray-300 mt-1">
          Color: ${item.color || "N/A"} | Size: ${item.size || "N/A"}
        </p>

        <div class="mt-3 flex items-center justify-between gap-4">
          <div class="text-sm">
            <p>Qty: <b>${item.qty}</b></p>
            <p>Price: <b>${money(item.price)}</b></p>
          </div>

          <div class="text-right">
            <p class="font-bold text-indigo-600">${money(item.total)}</p>

            <button onclick="removeCart(${item.id})"
              class="mt-2 text-sm bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-2xl">
              Remove
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
}

async function removeCart(cartId) {
  await apiDelete(`cart/remove/${cartId}/`, true);
  await loadCart();
}

function setTotals(items) {
  const subtotal = items.reduce((sum, x) => sum + Number(x.total || 0), 0);
  const vat = subtotal * 0.05;
  const total = subtotal + vat;

  subtotalEl.innerText = money(subtotal);
  vatEl.innerText = money(vat);
  totalEl.innerText = money(total);
}

function disableCheckout(msg) {
  checkoutBtn.disabled = true;
  addressNote.innerText = msg || "";
}

function enableCheckout(msg) {
  checkoutBtn.disabled = false;
  addressNote.innerText = msg || "";
}

async function loadProfileToCartInputs() {
  // default state
  cusDetails.value = "";
  shipDetails.value = "";

  if (!isLoggedIn()) return;

  const res = await apiGet("profile/", true);

  // profile missing / not set
  if (!res.status || !res.data) {
    disableCheckout("⚠️ Please set your address first from User Profile.");
    checkoutBtn.innerText = "Set Address First";
    return;
  }

  const p = res.data;

  const cusAddr = [
    p.cus_add, p.cus_city, p.cus_state, p.cus_postcode, p.cus_country
  ].filter(Boolean).join(", ");

  const shipAddr = [
    p.ship_add, p.ship_city, p.ship_state, p.ship_postcode, p.ship_country
  ].filter(Boolean).join(", ");

  cusDetails.value = cusAddr || "";
  shipDetails.value = shipAddr || "";

  // if empty -> force update
  if (!cusAddr || !shipAddr) {
    disableCheckout("⚠️ Please complete your profile address to checkout.");
    checkoutBtn.innerText = "Complete Address First";
    return;
  }

  enableCheckout("✅ Address loaded from your profile.");
  checkoutBtn.innerText = "Checkout (Pay Now)";
}

async function loadCart() {
  initNavbarAuth();

  if (!isLoggedIn()) {
    cartMsg.innerText = "";
    cartWrap.innerHTML = "";
    emptyCart.classList.remove("hidden");
    emptyCart.querySelector("p").innerText = "Please login first to view cart.";
    setTotals([]);
    disableCheckout("Login required.");
    checkoutBtn.innerText = "Login to Checkout";
    return;
  }

  cartMsg.innerText = "Loading...";
  disableCheckout("Loading profile...");

  const res = await apiGet("cart/list/", true);
  const items = res.data || [];

  if (!res.status) {
    cartMsg.innerText = "Failed to load cart.";
    cartWrap.innerHTML = "";
    emptyCart.classList.remove("hidden");
    setTotals([]);
    disableCheckout("Cart load failed.");
    checkoutBtn.innerText = "Checkout Disabled";
    return;
  }

  if (items.length === 0) {
    cartMsg.innerText = "";
    cartWrap.innerHTML = "";
    emptyCart.classList.remove("hidden");
    setTotals([]);
    disableCheckout("Add items to cart first.");
    checkoutBtn.innerText = "Cart Empty";
    return;
  }

  emptyCart.classList.add("hidden");
  cartMsg.innerText = `${items.length} item(s)`;
  cartWrap.innerHTML = items.map(cartItemCard).join("");

  setTotals(items);

  // load profile and enable/disable checkout based on address
  await loadProfileToCartInputs();
}

checkoutBtn.addEventListener("click", async () => {
  if (!isLoggedIn()) {
    alert("Please login first!");
    window.location.href = "/login/";
    return;
  }

  if (checkoutBtn.disabled) {
    alert("Please set your address first from User Profile.");
    window.location.href = "/profile-page/";
    return;
  }

  const cus = cusDetails.value.trim();
  const ship = shipDetails.value.trim();
  const method = document.querySelector("input[name='payMethod']:checked")?.value || "sslcommerz";

  if (!cus || !ship) {
    alert("Customer and Shipping details required!");
    return;
  }

  checkoutBtn.disabled = true;
  checkoutBtn.innerText = "Processing...";

  try {
    const res = await apiPost(
      "invoice/create/",
      { cus_details: cus, ship_details: ship, payment_method: method },
      true
    );

    // SSL Payment redirect
    if (res.status && res.data?.payment_method === "sslcommerz" && res.data?.payment_url) {
      window.location.href = res.data.payment_url;
      return;
    }

    // COD success
    if (res.status && res.data?.payment_method === "cod") {
      alert("✅ Order placed successfully (Cash On Delivery)!");
      window.location.href = "/orders/";
      return;
    }

    alert(res.message || "Failed to checkout!");
  } catch (e) {
    alert("Checkout error! Please try again.");
  } finally {
    checkoutBtn.disabled = false;
    checkoutBtn.innerText = "Confirm Order";
  }
});

loadCart();
