async function apiGet(endpoint, isAuth = false) {
  const headers = { "Content-Type": "application/json" };
  if (isAuth) Object.assign(headers, authHeader());

  const res = await fetch(`${BASE_URL}${endpoint}`, { headers });

  // ✅ If 401 -> auto logout (token expired)
  if (res.status === 401) {
    logout();
    return { status: false, message: "Unauthorized" };
  }

  return res.json();
}

async function apiPost(endpoint, body, isAuth = false) {
  const headers = { "Content-Type": "application/json" };
  if (isAuth) Object.assign(headers, authHeader());

  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });

  if (res.status === 401) {
    logout();
    return { status: false, message: "Unauthorized" };
  }

  return res.json();
}

async function apiDelete(endpoint, isAuth = false) {
  const headers = { "Content-Type": "application/json" };
  if (isAuth) Object.assign(headers, authHeader());

  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method: "DELETE",
    headers,
  });

  if (res.status === 401) {
    logout();
    return { status: false, message: "Unauthorized" };
  }

  return res.json();
}
