const ordersWrap = document.getElementById("ordersWrap");

// Review modal
const reviewModal = document.getElementById("reviewModal");
const closeReviewModal = document.getElementById("closeReviewModal");
const reviewProductTitle = document.getElementById("reviewProductTitle");
const reviewRating = document.getElementById("reviewRating");
const reviewText = document.getElementById("reviewText");
const submitReviewBtn = document.getElementById("submitReviewBtn");
const reviewMsg = document.getElementById("reviewMsg");

let currentReviewProductId = null;
let reviewedProductSet = new Set(); // ✅ must be declared before using

function money(n) {
  return `$${Number(n).toFixed(2)}`;
}

function badge(text, type = "gray") {
  const map = {
    gray: "bg-gray-500/20 text-gray-300 border-gray-500/30",
    yellow: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
    indigo: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
    green: "bg-green-500/20 text-green-300 border-green-500/30",
    red: "bg-red-500/20 text-red-300 border-red-500/30",
  };

  return `<span class="px-3 py-1 rounded-full text-xs font-semibold border ${map[type] || map.gray}">
    ${text}
  </span>`;
}

function paymentMethodBadge(method) {
  if (method === "cod") return badge("Cash On Delivery", "yellow");
  if (method === "sslcommerz") return badge("SSLCommerz", "indigo");
  return badge("UNKNOWN", "gray");
}

function paymentStatusBadge(status) {
  if (status === "paid") return badge("PAID", "green");
  if (status === "unpaid") return badge("UNPAID", "red");
  if (status === "failed") return badge("FAILED", "red");
  return badge(String(status || "UNKNOWN").toUpperCase(), "gray");
}

function deliveryStatusBadge(status) {
  if (status === "pending") return badge("PENDING", "gray");
  if (status === "processing") return badge("PROCESSING", "yellow");
  if (status === "delivered") return badge("DELIVERED", "green");
  return badge(String(status || "UNKNOWN").toUpperCase(), "gray");
}

function productMiniCard(p, allowReview = false) {
  const isReviewed = reviewedProductSet.has(p.product);

  let reviewBtnHtml = "";
  if (allowReview) {
    if (isReviewed) {
      reviewBtnHtml = `
        <button
          class="px-4 py-2 rounded-xl bg-gray-700 text-white text-xs font-semibold cursor-not-allowed opacity-70"
          disabled>
          ✅ Reviewed
        </button>
      `;
    } else {
      reviewBtnHtml = `
        <button
          id="reviewBtn_${p.product}"
          class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
          onclick="openReviewModal(${p.product})">
          ⭐ Review
        </button>
      `;
    }
  }

  return `
    <div class="flex items-center gap-3 bg-gray-50/5 border border-white/10 rounded-2xl p-3">
      <img src="${p.product_image}" class="w-12 h-12 rounded-xl object-cover border border-white/10"/>
      <div class="flex-1">
        <p class="font-semibold text-sm">${p.product_title}</p>
        <p class="text-xs text-gray-400">Qty: ${p.qty} | Price: ${money(p.sale_price)}</p>
      </div>
      ${reviewBtnHtml}
    </div>
  `;
}

function invoiceCard(inv) {
  const allowReview = inv.delivery_status === "delivered";

  return `
    <div class="bg-white/5 border border-white/10 rounded-3xl shadow p-5">
      <div class="flex items-start justify-between gap-4">
        <div>
          <h3 class="text-lg font-bold">Invoice #${inv.id}</h3>
          <p class="text-xs text-gray-400 mt-1">TranID: ${inv.tran_id || "-"}</p>
        </div>

        <div class="flex flex-wrap gap-2 justify-end">
          ${paymentMethodBadge(inv.payment_method)}
          ${paymentStatusBadge(inv.payment_status)}
          ${deliveryStatusBadge(inv.delivery_status)}
        </div>
      </div>

      <div class="grid md:grid-cols-3 gap-4 mt-5">
        <div class="bg-white/5 border border-white/10 rounded-2xl p-4">
          <p class="text-xs text-gray-400">Subtotal</p>
          <p class="font-bold">${money(inv.total)}</p>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-2xl p-4">
          <p class="text-xs text-gray-400">VAT</p>
          <p class="font-bold">${money(inv.vat)}</p>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-2xl p-4">
          <p class="text-xs text-gray-400">Payable</p>
          <p class="font-bold text-indigo-300">${money(inv.payable)}</p>
        </div>
      </div>

      <div class="grid md:grid-cols-2 gap-4 mt-4">
        <div class="bg-white/5 border border-white/10 rounded-2xl p-4">
          <p class="text-xs text-gray-400">Customer Details</p>
          <p class="text-sm font-semibold mt-1">${inv.cus_details}</p>
        </div>

        <div class="bg-white/5 border border-white/10 rounded-2xl p-4">
          <p class="text-xs text-gray-400">Shipping Details</p>
          <p class="text-sm font-semibold mt-1">${inv.ship_details}</p>
        </div>
      </div>

      <div class="mt-4">
        <p class="text-sm font-bold mb-2">Products</p>
        <div class="grid gap-3">
          ${(inv.products || []).map(p => productMiniCard(p, allowReview)).join("")}
        </div>
      </div>
    </div>
  `;
}

function section(title, subtitle, list) {
  return `
    <div>
      <div class="flex items-end justify-between mb-3">
        <div>
          <h3 class="text-xl font-bold">${title}</h3>
          <p class="text-sm text-gray-400">${subtitle}</p>
        </div>
        <span class="text-xs text-gray-400">${list.length} invoice(s)</span>
      </div>

      <div class="space-y-6">
        ${list.map(invoiceCard).join("")}
      </div>
    </div>
  `;
}

// ✅ Review Modal Functions
window.openReviewModal = function (productId) {
  currentReviewProductId = productId;
  reviewMsg.innerText = "";
  reviewText.value = "";
  reviewRating.value = "5";
  reviewProductTitle.innerText = `Product ID: ${productId}`;
  reviewModal.classList.remove("hidden");
};

closeReviewModal.addEventListener("click", () => {
  reviewModal.classList.add("hidden");
});

reviewModal.addEventListener("click", (e) => {
  if (e.target === reviewModal) reviewModal.classList.add("hidden");
});

submitReviewBtn.addEventListener("click", async () => {
  reviewMsg.innerText = "Submitting...";
  reviewMsg.className = "text-sm font-semibold text-center text-gray-400";

  const rating = parseInt(reviewRating.value);
  const description = reviewText.value.trim();

  if (!currentReviewProductId) {
    reviewMsg.innerText = "Product missing!";
    reviewMsg.className = "text-sm font-semibold text-center text-red-400";
    return;
  }

  if (!description) {
    reviewMsg.innerText = "Write something in review!";
    reviewMsg.className = "text-sm font-semibold text-center text-red-400";
    return;
  }

  const res = await apiPost("api/review/create/", {
    product_id: currentReviewProductId,
    rating,
    description
  }, true);

  if (res.status) {
    reviewMsg.innerText = "✅ Review submitted!";
    reviewMsg.className = "text-sm font-semibold text-center text-green-400";

    // ✅ Mark as reviewed
    reviewedProductSet.add(currentReviewProductId);

    // ✅ update button instantly
    const btn = document.getElementById(`reviewBtn_${currentReviewProductId}`);
    if (btn) {
      btn.innerHTML = "✅ Reviewed";
      btn.className =
        "px-4 py-2 rounded-xl bg-gray-700 text-white text-xs font-semibold cursor-not-allowed opacity-70";
      btn.disabled = true;
      btn.onclick = null;
    }

    setTimeout(() => reviewModal.classList.add("hidden"), 800);
  } else {
    reviewMsg.innerText = res.message || "❌ Failed!";
    reviewMsg.className = "text-sm font-semibold text-center text-red-400";
  }
});

async function loadOrders() {
  initNavbarAuth();

  if (!isLoggedIn()) {
    ordersWrap.innerHTML = `
      <div class="bg-white/5 border border-white/10 rounded-3xl p-10 text-center">
        <h3 class="text-xl font-bold">Please login first</h3>
        <p class="text-gray-400 mt-2">You need login to see your orders.</p>
        <a href="/login/" class="inline-block mt-4 bg-indigo-600 text-white px-6 py-2 rounded-2xl font-semibold">
          Login
        </a>
      </div>
    `;
    return;
  }

  // ✅ load reviewed product list (must be inside async function)
  const reviewedRes = await apiGet("api/review/reviewed-products/", true);
  const reviewedIds = reviewedRes.data || [];
  reviewedProductSet = new Set(reviewedIds);

  const res = await apiGet("api/orders/", true);
  const orders = res.data || [];

  const pending = orders.filter(o => o.delivery_status === "pending");
  const processing = orders.filter(o => o.delivery_status === "processing");
  const delivered = orders.filter(o => o.delivery_status === "delivered");

  ordersWrap.innerHTML = `
    ${pending.length ? section("🕒 Pending", "Orders waiting for processing", pending) : ""}
    ${processing.length ? section("⚙️ Processing", "Your orders are being prepared", processing) : ""}
    ${delivered.length ? section("✅ Delivered", "Orders delivered successfully (review available)", delivered) : ""}
    ${orders.length === 0 ? `
      <div class="bg-white/5 border border-white/10 rounded-3xl p-10 text-center">
        <h3 class="text-xl font-bold">No orders found</h3>
        <p class="text-gray-400 mt-2">Order something first.</p>
        <a href="/product/" class="inline-block mt-4 bg-indigo-600 text-white px-6 py-2 rounded-2xl font-semibold">
          Shop Now
        </a>
      </div>
    ` : ""}
  `;
}

loadOrders();
