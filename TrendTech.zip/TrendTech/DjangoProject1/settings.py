import os.path
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent


SECRET_KEY = 'django-insecure-&=)ltekn-vp^fk+a&k-0-*ct$x9)-jzb1e_!fk-^%_enq4888='
DEBUG = True

ALLOWED_HOSTS = ["*", "localhost", "127.0.0.1","https://placehold.co"]

INSTALLED_APPS = [
    "unfold",
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'myapp'
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

CORS_ALLOW_ALL_ORIGINS = True
ROOT_URLCONF = 'DjangoProject1.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates']
        ,
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'DjangoProject1.wsgi.application'


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True



STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# REST Framework Configuration
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
    ],
    'DEFAULT_PARSER_CLASSES': [
        'rest_framework.parsers.JSONParser',
    ],
    'DEFAULT_AUTHENTICATION_CLASSES': [],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.AllowAny',
    ],
}


LOGGING = {
    "version":1,
    "disable_existing_loggers": False,
    "handlers": {
       "file":{
           "level":"DEBUG",
           "class":"logging.FileHandler",
           "filename":os.path.join(BASE_DIR,'debug.log')
       }
    },
    "loggers": {
        "myapp_logger": {
            "handlers": ["file"],
            "level": "DEBUG",
            "propagate": False,
        },
    },
}

AUTH_USER_MODEL = "myapp.User"

EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True

EMAIL_HOST_USER = ''
EMAIL_HOST_PASSWORD = ''

DEFAULT_FROM_EMAIL = EMAIL_HOST_USER

# Unfold Admin Configuration

UNFOLD = {
    "SITE_TITLE": "TrendTech Admin",
    "SITE_HEADER": "TrendTech",
    "SITE_URL": "/admin/",
    "SITE_SYMBOL": "dashboard",

    "STYLES": [
        "/static/admin_custom.css",
    ],

    # Premium Purple Theme
    "COLORS": {
        "primary": {
            "50": "250 245 255",
            "100": "243 232 255",
            "200": "233 213 255",
            "300": "216 180 254",
            "400": "192 132 252",
            "500": "168 85 247",
            "600": "147 51 234",
            "700": "126 34 206",
            "800": "107 33 168",
            "900": "88 28 135",
            "950": "59 7 100",
        }
    },

    # Sidebar Menu
    "SIDEBAR": {
        "show_search": True,
        "show_all_applications": False,
        "navigation": [
            {
                "title": "Main",
                "items": [
                    {
                        "title": "Dashboard",
                        "icon": "dashboard",
                        "link": "/admin/",
                    },
                ],
            },

            {
                "title": "Shop Management",
                "items": [
                    {
                        "title": "Brands",
                        "icon": "sell",
                        "link": "/admin/myapp/brand/",
                    },
                    {
                        "title": "Categories",
                        "icon": "category",
                        "link": "/admin/myapp/category/",
                    },
                    {
                        "title": "Products",
                        "icon": "inventory_2",
                        "link": "/admin/myapp/product/",
                    },
                    {
                        "title": "Product Sliders",
                        "icon": "slideshow",
                        "link": "/admin/myapp/productslider/",
                    },
                    {
                        "title": "Product Details",
                        "icon": "description",
                        "link": "/admin/myapp/productdetail/",
                    },
                ],
            },

            {
                "title": "Customers",
                "items": [
                    {
                        "title": "Customer Profiles",
                        "icon": "person",
                        "link": "/admin/myapp/customerprofile/",
                    },
                    {
                        "title": "Carts",
                        "icon": "shopping_cart",
                        "link": "/admin/myapp/productcart/",
                    },
                    {
                        "title": "Wishlists",
                        "icon": "favorite",
                        "link": "/admin/myapp/productwish/",
                    },
                    {
                        "title": "Reviews",
                        "icon": "rate_review",
                        "link": "/admin/myapp/productreview/",
                    },
                ],
            },

            {
                "title": "Orders & Payments",
                "items": [
                    {
                        "title": "Invoices",
                        "icon": "receipt_long",
                        "link": "/admin/myapp/invoice/",
                    },
                    {
                        "title": "Invoice Products",
                        "icon": "shopping_bag",
                        "link": "/admin/myapp/invoiceproduct/",
                    },
                    {
                        "title": "SSLCommerz Accounts",
                        "icon": "payments",
                        "link": "/admin/myapp/sslcommerzaccount/",
                    },
                ],
            },

            {
                "title": "System",
                "items": [
                    {
                        "title": "Policies",
                        "icon": "policy",
                        "link": "/admin/myapp/policy/",
                    },
                ],
            },

            {
                "title": "Authentication",
                "items": [
                    {
                        "title": "Users",
                        "icon": "group",
                        "link": "/admin/myapp/user/",
                    },
                    {
                        "title": "Groups",
                        "icon": "admin_panel_settings",
                        "link": "/admin/auth/group/",
                    },
                ],
            },
        ],
    },
}
