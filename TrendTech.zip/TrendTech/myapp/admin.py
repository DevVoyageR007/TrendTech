from django.contrib import admin
from django.contrib.auth.models import Group
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.admin import GroupAdmin as BaseGroupAdmin
from django.utils.html import format_html
from .admin_site import admin_site


from .models import (
    Brand, Category, Product, ProductSlider, ProductDetail, ProductReview,
    User, CustomerProfile, ProductCart, ProductWish, Invoice, InvoiceProduct,
    SSLCommerzAccount, Policy
)

class GroupAdmin(BaseGroupAdmin):
    filter_horizontal = ("permissions",)
    search_fields = ("name",)
    ordering = ("name",)

# Custom User Admin
class UserAdmin(BaseUserAdmin):
    model = User
    list_display = ("id", "email", "username", "is_staff", "is_active", "created_at")
    search_fields = ("email", "username")
    ordering = ("id",)
    list_per_page = 10

    readonly_fields = ("created_at", "updated_at", "last_login", "date_joined")

    fieldsets = (
        ("User Info", {"fields": ("username", "email", "password")}),
        ("OTP Info", {"fields": ("otp_hash", "otp_created_at", "otp_attempts")}),
        ("Permissions", {"fields": ("is_staff", "is_active", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "date_joined", "created_at", "updated_at")}),
    )

    add_fieldsets = (
        ("Create User", {
            "classes": ("wide",),
            "fields": ("username", "email", "password1", "password2", "is_staff", "is_active"),
        }),
    )

# Brand Admin
class BrandAdmin(admin.ModelAdmin):
    list_display = ("id", "brandName", "brand_preview", "created_at")
    search_fields = ("brandName",)
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

    def brand_preview(self, obj):
        return format_html('<img src="{}" style="height:35px;border-radius:6px;" />', obj.brandImg)
    brand_preview.short_description = "Logo"

# Category Admin
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "categoryName", "category_preview", "created_at")
    search_fields = ("categoryName",)
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

    def category_preview(self, obj):
        return format_html('<img src="{}" style="height:35px;border-radius:6px;" />', obj.categoryImg)
    category_preview.short_description = "Image"

# Product Admin
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        "id", "title", "product_preview", "brand", "category",
        "price", "discount", "discount_price",
        "stock", "star", "remark"
    )
    search_fields = ("title", "brand__brandName", "category__categoryName")
    list_filter = ("remark", "brand", "category")
    ordering = ("id",)
    list_per_page = 10
    list_editable = ("price","discount", "discount_price","stock", "remark")

    readonly_fields = ("created_at", "updated_at")

    def product_preview(self, obj):
        return format_html('<img src="{}" style="height:40px;border-radius:8px;" />', obj.image)
    product_preview.short_description = "Image"

# Product Slider Admin
class ProductSliderAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "slider_preview", "price", "product", "created_at")
    search_fields = ("title", "product__title")
    ordering = ("id",)
    list_per_page = 10
    list_editable = ("price",)

    readonly_fields = ("created_at", "updated_at")

    def slider_preview(self, obj):
        return format_html('<img src="{}" style="height:40px;border-radius:8px;" />', obj.image)
    slider_preview.short_description = "Image"

# Product Detail Admin
class ProductDetailAdmin(admin.ModelAdmin):
    list_display = ("id", "product", "color", "size", "created_at")
    search_fields = ("product__title", "color", "size")
    ordering = ("id",)
    list_editable = ("color", "size")
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Customer Profile Admin
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "cus_name", "cus_city", "cus_country", "cus_phone", "user", "created_at")
    search_fields = ("cus_name", "cus_city", "cus_country", "cus_phone", "user__email")
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Cart Admin
class ProductCartAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "product", "qty", "price", "created_at")
    search_fields = ("user__email", "product__title")
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Wishlist Admin
class ProductWishAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "product", "created_at")
    search_fields = ("user__email", "product__title")
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Review Admin
class ProductReviewAdmin(admin.ModelAdmin):
    list_display = ("id", "customer", "product", "rating", "created_at")
    search_fields = ("customer__cus_name", "product__title")
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Invoice Inline
class InvoiceProductInline(admin.TabularInline):
    model = InvoiceProduct
    extra = 0
    readonly_fields = ("product", "qty", "sale_price", "created_at")

# Invoice Admin
class InvoiceAdmin(admin.ModelAdmin):
    list_display = (
        "id", "user", "payment_method", "payment_status",
        "delivery_status", "total", "vat", "payable", "created_at"
    )
    search_fields = ("user__email", "tran_id")
    list_filter = ("payment_method", "payment_status", "delivery_status")
    ordering = ("id",)
    list_per_page = 10
    list_editable = ("payment_status", "delivery_status")
    readonly_fields = ("created_at", "updated_at")

    inlines = [InvoiceProductInline]

# InvoiceProduct Admin
class InvoiceProductAdmin(admin.ModelAdmin):
    list_display = ("id", "invoice", "product", "qty", "sale_price", "created_at")
    search_fields = ("invoice__id", "product__title")
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# SSLCommerz Account Admin
class SSLCommerzAccountAdmin(admin.ModelAdmin):
    list_display = ("id", "store_id", "currency", "created_at")
    search_fields = ("store_id",)
    ordering = ("id",)
    list_per_page = 10
    readonly_fields = ("created_at", "updated_at")

# Policy Admin
class PolicyAdmin(admin.ModelAdmin):
    list_display = ("id", "type")
    search_fields = ("type",)
    ordering = ("id",)
    list_per_page = 10

# Registering models with custom admin site
admin_site.register(Group, GroupAdmin)
admin_site.register(User, UserAdmin)
admin_site.register(Brand, BrandAdmin)
admin_site.register(Category, CategoryAdmin)
admin_site.register(Product, ProductAdmin)
admin_site.register(ProductSlider, ProductSliderAdmin)
admin_site.register(ProductDetail, ProductDetailAdmin)
admin_site.register(CustomerProfile, CustomerProfileAdmin)
admin_site.register(ProductCart, ProductCartAdmin)
admin_site.register(ProductWish, ProductWishAdmin)
admin_site.register(ProductReview, ProductReviewAdmin)
admin_site.register(Invoice, InvoiceAdmin)
admin_site.register(InvoiceProduct, InvoiceProductAdmin)
admin_site.register(SSLCommerzAccount, SSLCommerzAccountAdmin)
admin_site.register(Policy, PolicyAdmin)