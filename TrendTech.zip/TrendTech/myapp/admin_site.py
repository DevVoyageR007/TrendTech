from unfold.sites import UnfoldAdminSite
from django.db.models import Count

from .models import Product, Invoice, CustomerProfile, InvoiceProduct


class MyAdminSite(UnfoldAdminSite):   # ✅ এখানে AdminSite না, UnfoldAdminSite
    site_header = "TrendTech Admin Panel"
    site_title = "TrendTech Admin"
    index_title = "Dashboard"

    def index(self, request, extra_context=None):
        extra_context = extra_context or {}

        total_products = Product.objects.count()
        total_orders = Invoice.objects.count()
        total_customers = CustomerProfile.objects.count()

        pending_orders = Invoice.objects.filter(delivery_status="pending").count()
        paid_orders = Invoice.objects.filter(payment_status="paid").count()
        low_stock_count = Product.objects.filter(stock__lte=10).count()

        status_data = (
            Invoice.objects.values("delivery_status")
            .annotate(total=Count("id"))
            .order_by("delivery_status")
        )
        labels = [x["delivery_status"] for x in status_data]
        values = [x["total"] for x in status_data]

        top_products = (
            InvoiceProduct.objects.values("product__title")
            .annotate(total=Count("id"))
            .order_by("-total")[:5]
        )
        top_labels = [x["product__title"] for x in top_products]
        top_values = [x["total"] for x in top_products]

        latest_orders = Invoice.objects.select_related("user").order_by("-id")[:10]

        extra_context.update({
            "total_products": total_products,
            "total_orders": total_orders,
            "total_customers": total_customers,
            "pending_orders": pending_orders,
            "paid_orders": paid_orders,
            "low_stock_count": low_stock_count,
            "labels": labels,
            "values": values,
            "top_labels": top_labels,
            "top_values": top_values,
            "latest_orders": latest_orders,
        })

        return super().index(request, extra_context=extra_context)


# ✅ name MUST be "admin" for unfold links
admin_site = MyAdminSite(name="admin")
