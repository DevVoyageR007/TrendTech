from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name="home"),
    path("brands/", views.brand_list),
    path("categories/", views.category_list),
    path("products/category/<int:category_id>/", views.product_by_category),
    path("products/remark/<str:remark>/", views.product_by_remark),
    path("products/brand/<int:brand_id>/", views.product_by_brand),
    path("products/sliders/", views.product_slider_list),
    path("products/search/", views.product_by_keyword),
    path("products/<int:product_id>/", views.product_details),
    path("product-details/", views.product_details_page, name="product_details_page"),
    path("product/", views.product_list, name="products"),


    path("login/", views.user_login, name="login"),
    path("verify-otp/", views.verify_otp),

    path("profile-page/", views.profile_page, name="profile_page"),
    path("profile/", views.profile_get, name="profile_get"),
    path("profile/update/", views.profile_update, name="profile_update"),

    path("cart/add/", views.cart_add),
    path("cart/remove/<int:cart_id>/", views.cart_remove),
    path("cart/list/", views.cart_list),
    path("cart/", views.cart_page, name="cart"),


    path("wish/add/", views.wish_add),
    path("wish/remove/<int:wish_id>/", views.wish_remove),
    path("wish/list/", views.wish_list),
    path("wish/", views.wish_page, name="wish"),

    path("orders/", views.orders_page, name="orders"),
    path("api/orders/", views.my_orders),
    path("api/review/create/", views.create_review), 
    path("api/review/reviewed-products/", views.reviewed_products),
    path("invoice/create/", views.create_invoice),
    path("invoice/list/", views.invoice_list),

    # Payment callback endpoints
    path("PaymentSuccess", views.payment_success, name='payment_success'),
    path("PaymentFail", views.payment_fail, name='payment_fail'),
    path("PaymentCancel", views.payment_cancel, name='payment_cancel'),
    path("api/PaymentIPN", views.payment_ipn, name='payment_ipn'),

]
