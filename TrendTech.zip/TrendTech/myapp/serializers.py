from rest_framework import serializers
from .models import (
    Brand, Category, Product, ProductSlider, ProductDetail,
    User,CustomerProfile, ProductCart, ProductWish, Invoice, InvoiceProduct
)

class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brand
        fields = ['id', 'brandName', 'brandImg']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'categoryName', 'categoryImg']


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = [
            'id', 'title', 'short_des', 'price', 'discount',
            'discount_price', 'image', 'stock', 'star', 'remark',
            'category', 'brand'
        ]


class ProductListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'title', 'price', 'discount_price', 'image', 'remark', 'star']


class ProductSliderSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductSlider
        fields = ['id', 'title', 'short_des', 'price', 'image', 'product']


class ProductDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductDetail
        fields = ['img1', 'img2', 'img3', 'img4', 'des', 'color', 'size']


class ProductWithDetailsSerializer(serializers.Serializer):
    product = ProductSerializer()
    details = ProductDetailSerializer()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email']


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()


class VerifyOTPSerializer(serializers.Serializer):
    email = serializers.EmailField()
    otp = serializers.CharField(max_length=10)

class CustomerProfileSerializer(serializers.ModelSerializer):
    profile_pic_url = serializers.SerializerMethodField()

    class Meta:
        model = CustomerProfile
        fields = [
            "id",
            "cus_name","cus_add","cus_city","cus_state","cus_postcode","cus_country","cus_phone","cus_fax",
            "ship_name","ship_add","ship_city","ship_state","ship_postcode","ship_country","ship_phone",
            "profile_pic","profile_pic_url"
        ]

    def get_profile_pic_url(self, obj):
        if obj.profile_pic:
            return obj.profile_pic.url
        return ""

class ProductCartSerializer(serializers.ModelSerializer):
    product_title = serializers.CharField(source='product.title', read_only=True)
    product_image = serializers.CharField(source='product.image', read_only=True)

    class Meta:
        model = ProductCart
        fields = [
            'id', 'product', 'product_title', 'product_image',
            'color', 'size', 'qty', 'price'
        ]
        read_only_fields = ['id', 'price']


class CartAddSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    color = serializers.CharField(max_length=255, required=False, allow_blank=True, default='')
    size = serializers.CharField(max_length=255, required=False, allow_blank=True, default='')
    qty = serializers.CharField(max_length=50, default='1')


class ProductWishSerializer(serializers.ModelSerializer):
    product_title = serializers.CharField(source='product.title', read_only=True)
    product_image = serializers.CharField(source='product.image', read_only=True)
    product_price = serializers.CharField(source='product.price', read_only=True)
    product_discount_price = serializers.CharField(source='product.discount_price', read_only=True)
    product_star = serializers.FloatField(source='product.star', read_only=True)

    class Meta:
        model = ProductWish
        fields = [
            'id', 'product', 'product_title', 'product_image',
            'product_price', 'product_discount_price', 'product_star'
        ]
        read_only_fields = ['id']


class WishAddSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()


class InvoiceProductSerializer(serializers.ModelSerializer):
    product_title = serializers.CharField(source='product.title', read_only=True)
    product_image = serializers.CharField(source='product.image', read_only=True)

    class Meta:
        model = InvoiceProduct
        fields = [
            'id', 'product', 'product_title', 'product_image',
            'qty', 'sale_price'
        ]


class InvoiceSerializer(serializers.ModelSerializer):
    products = InvoiceProductSerializer(source='invoiceproduct_set', many=True, read_only=True)

    class Meta:
        model = Invoice
        fields = [
            'id', 'total', 'vat', 'payable', 'cus_details',
            'ship_details', 'payment_method', 'tran_id', 'val_id', 'delivery_status',
            'payment_status', 'created_at', 'products'
        ]
        read_only_fields = ['id', 'tran_id', 'created_at']


class CreateInvoiceSerializer(serializers.Serializer):
    cus_details = serializers.CharField()
    ship_details = serializers.CharField()
    payment_method = serializers.ChoiceField(choices=["sslcommerz", "cod"])

class CreateReviewSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    rating = serializers.IntegerField(min_value=1, max_value=5)
    description = serializers.CharField()