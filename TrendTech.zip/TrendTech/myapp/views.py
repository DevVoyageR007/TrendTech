import random
import jwt
import requests
import uuid
from datetime import datetime, timedelta
from django.utils import timezone
from django.core.mail import send_mail
from django.contrib.auth.hashers import make_password, check_password
from django.conf import settings
from django.shortcuts import render
from rest_framework.decorators import api_view, authentication_classes, permission_classes, parser_classes
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.parsers import MultiPartParser, FormParser

from .models import (
    Brand, Category, Product, ProductSlider, ProductDetail,ProductReview,
    User, CustomerProfile, ProductCart, ProductWish, Invoice, InvoiceProduct, SSLCommerzAccount
)
from .serializers import (
    BrandSerializer, CategorySerializer, ProductListSerializer, ProductSerializer,
    ProductSliderSerializer, ProductDetailSerializer,
    LoginSerializer, VerifyOTPSerializer, CustomerProfileSerializer, CartAddSerializer,
    WishAddSerializer, CreateInvoiceSerializer, InvoiceProductSerializer, InvoiceSerializer, CreateReviewSerializer
)
from .drf_auth import JWTAuthentication


def home(request):
    return render(request, 'home.html')

@api_view(['GET'])
@permission_classes([AllowAny])
def brand_list(request):
    brands = Brand.objects.all()
    serializer = BrandSerializer(brands, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def category_list(request):
    categories = Category.objects.all()
    serializer = CategorySerializer(categories, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_by_category(request, category_id):
    products = Product.objects.filter(category_id=category_id)
    serializer = ProductListSerializer(products, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_by_remark(request, remark):
    products = Product.objects.filter(remark=remark)
    serializer = ProductListSerializer(products, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_slider_list(request):
    sliders = ProductSlider.objects.all()
    serializer = ProductSliderSerializer(sliders, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_by_keyword(request):
    keyword = request.GET.get("keyword", "")
    products = Product.objects.filter(title__icontains=keyword)
    serializer = ProductListSerializer(products, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_details(request, product_id):
    try:
        product = Product.objects.get(id=product_id)
        details = ProductDetail.objects.get(product_id=product_id)
    except Product.DoesNotExist:
        return Response({
            "status": False,
            "message": "Product not found"
        }, status=status.HTTP_404_NOT_FOUND)
    except ProductDetail.DoesNotExist:
        return Response({
            "status": False,
            "message": "Product details not found"
        }, status=status.HTTP_404_NOT_FOUND)

    product_serializer = ProductSerializer(product)
    details_serializer = ProductDetailSerializer(details)

    return Response({
        "status": True,
        "message": "success",
        "data": {
            "product": product_serializer.data,
            "details": details_serializer.data
        }
    })


@api_view(['GET'])
@permission_classes([AllowAny])
def product_by_brand(request, brand_id):
    products = Product.objects.filter(brand_id=brand_id)
    serializer = ProductListSerializer(products, many=True)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })


@api_view(['GET', 'POST'])
@permission_classes([AllowAny])
def user_login(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    serializer = LoginSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    email = serializer.validated_data['email']
    otp = f"{random.randint(0, 9999):04d}"   # 0000-9999 safe 4 digit
    otp_hash = make_password(otp)            # hash

    user, _ = User.objects.get_or_create(email=email)
    user.otp_hash = otp_hash
    user.otp_created_at = timezone.now()
    user.otp_attempts = 0
    user.save(update_fields=["otp_hash", "otp_created_at", "otp_attempts"])

    # Send OTP email
    send_mail(
        subject="Your OTP Code",
        message=f"Your OTP is: {otp}\nThis OTP is valid for 1 minute.",
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[email],
        fail_silently=False,
    )

    return Response({
        "status": True,
        "message": "OTP sent successfully"
    }, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([AllowAny])
def verify_otp(request):
    serializer = VerifyOTPSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    email = serializer.validated_data['email']
    otp = serializer.validated_data['otp']

    try:
        user = User.objects.get(email=email)
    except User.DoesNotExist:
        return Response({"status": False, "message": "Invalid email or OTP"},
                        status=status.HTTP_401_UNAUTHORIZED)

    # OTP exist check
    if not user.otp_hash or not user.otp_created_at:
        return Response({"status": False, "message": "OTP not requested"},
                        status=status.HTTP_400_BAD_REQUEST)

    # 1 minute expiry
    if timezone.now() > user.otp_created_at + timedelta(minutes=1):
        return Response({"status": False, "message": "OTP expired"},
                        status=status.HTTP_401_UNAUTHORIZED)

    # Optional: attempt limit
    if user.otp_attempts >= 3:
        return Response({"status": False, "message": "Too many attempts. Request new OTP."},
                        status=status.HTTP_429_TOO_MANY_REQUESTS)

    # hash match
    if not check_password(otp, user.otp_hash):
        user.otp_attempts += 1
        user.save(update_fields=["otp_attempts"])
        return Response({"status": False, "message": "Invalid email or OTP"},
                        status=status.HTTP_401_UNAUTHORIZED)

    # Clear OTP fields after successful verification
    user.otp_hash = None
    user.otp_created_at = None
    user.otp_attempts = 0
    user.save(update_fields=["otp_hash", "otp_created_at", "otp_attempts"])

    payload = {
        "user_id": user.id,
        "user_email": user.email,
        "iat": int(timezone.now().timestamp()),
        "exp": int((timezone.now() + timedelta(days=7)).timestamp())
    }
    token = jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")

    return Response({
        "status": True,
        "message": "Login successful",
        "token": token,
        "data": {"user_id": user.id, "user_email": user.email}
    }, status=status.HTTP_200_OK)

@api_view(["GET"])
@authentication_classes([JWTAuthentication])
def profile_get(request):
    profile = CustomerProfile.objects.filter(user_id=request.user_id).first()

    if not profile:
        return Response({
            "status": True,
            "message": "Profile not created yet",
            "data": None
        })

    serializer = CustomerProfileSerializer(profile)
    return Response({
        "status": True,
        "message": "success",
        "data": serializer.data
    })

@api_view(["POST"])
@authentication_classes([JWTAuthentication])
@parser_classes([MultiPartParser, FormParser])
def profile_update(request):
    profile, _ = CustomerProfile.objects.get_or_create(user_id=request.user_id)

    # text fields update
    profile.cus_name = request.data.get("cus_name", profile.cus_name)
    profile.cus_add = request.data.get("cus_add", profile.cus_add)
    profile.cus_city = request.data.get("cus_city", profile.cus_city)
    profile.cus_state = request.data.get("cus_state", profile.cus_state)
    profile.cus_postcode = request.data.get("cus_postcode", profile.cus_postcode)
    profile.cus_country = request.data.get("cus_country", profile.cus_country)
    profile.cus_phone = request.data.get("cus_phone", profile.cus_phone)
    profile.cus_fax = request.data.get("cus_fax", profile.cus_fax)

    profile.ship_name = request.data.get("ship_name", profile.ship_name)
    profile.ship_add = request.data.get("ship_add", profile.ship_add)
    profile.ship_city = request.data.get("ship_city", profile.ship_city)
    profile.ship_state = request.data.get("ship_state", profile.ship_state)
    profile.ship_postcode = request.data.get("ship_postcode", profile.ship_postcode)
    profile.ship_country = request.data.get("ship_country", profile.ship_country)
    profile.ship_phone = request.data.get("ship_phone", profile.ship_phone)

    # image upload
    if "profile_pic" in request.FILES:
        profile.profile_pic = request.FILES["profile_pic"]

    profile.save()

    serializer = CustomerProfileSerializer(profile)
    return Response({
        "status": True,
        "message": "Profile updated",
        "data": serializer.data
    })

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
def cart_add(request):
    serializer = CartAddSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    product_id = serializer.validated_data['product_id']
    color = serializer.validated_data.get('color', '')
    size = serializer.validated_data.get('size', '')
    qty = serializer.validated_data.get('qty', '1')

    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return Response({
            "status": False,
            "message": "Product not found"
        }, status=status.HTTP_404_NOT_FOUND)

    cart_item, created = ProductCart.objects.get_or_create(
        user_id=request.user_id,
        product_id=product_id,
        color=color,
        size=size,
        defaults={'qty': qty, 'price': product.discount_price}
    )

    if not created:
        cart_item.qty = str(int(cart_item.qty) + int(qty))
        cart_item.save()

    return Response({
        "status": True,
        "message": "Product added to cart"
    })


@api_view(['DELETE'])
@authentication_classes([JWTAuthentication])
def cart_remove(request, cart_id):
    try:
        cart_item = ProductCart.objects.get(id=cart_id, user_id=request.user_id)
        cart_item.delete()
        return Response({
            "status": True,
            "message": "Product removed from cart"
        })
    except ProductCart.DoesNotExist:
        return Response({
            "status": False,
            "message": "Cart item not found"
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
@authentication_classes([JWTAuthentication])
def cart_list(request):
    cart_items = ProductCart.objects.filter(user_id=request.user_id).select_related('product')
    data = []
    for item in cart_items:
        data.append({
            "id": item.id,
            "product_id": item.product.id,
            "product_title": item.product.title,
            "product_image": item.product.image,
            "color": item.color,
            "size": item.size,
            "qty": item.qty,
            "price": item.price,
            "total": str(int(item.qty) * float(item.price))
        })

    return Response({
        "status": True,
        "message": "success",
        "data": data
    })



@api_view(['POST'])
@authentication_classes([JWTAuthentication])
def wish_add(request):
    serializer = WishAddSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    product_id = serializer.validated_data['product_id']

    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return Response({
            "status": False,
            "message": "Product not found"
        }, status=status.HTTP_404_NOT_FOUND)

    wish_item, created = ProductWish.objects.get_or_create(
        user_id=request.user_id,
        product_id=product_id
    )

    if not created:
        return Response({
            "status": False,
            "message": "Product already in wishlist"
        }, status=status.HTTP_400_BAD_REQUEST)

    return Response({
        "status": True,
        "message": "Product added to wishlist"
    })


@api_view(['DELETE'])
@authentication_classes([JWTAuthentication])
def wish_remove(request, wish_id):
    try:
        wish_item = ProductWish.objects.get(id=wish_id, user_id=request.user_id)
        wish_item.delete()
        return Response({
            "status": True,
            "message": "Product removed from wishlist"
        })
    except ProductWish.DoesNotExist:
        return Response({
            "status": False,
            "message": "Wishlist item not found"
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
@authentication_classes([JWTAuthentication])
def wish_list(request):
    wish_items = ProductWish.objects.filter(user_id=request.user_id).select_related('product')

    data = []
    for item in wish_items:
        data.append({
            "id": item.id,
            "product_id": item.product.id,
            "product_title": item.product.title,
            "product_image": item.product.image,
            "product_price": item.product.price,
            "product_discount_price": item.product.discount_price,
            "product_star": item.product.star
        })

    return Response({
        "status": True,
        "message": "success",
        "data": data
    })



@api_view(['POST'])
@authentication_classes([JWTAuthentication])
def create_invoice(request):
    """Create invoice from cart items and initiate payment (SSLCommerz or COD)"""

    serializer = CreateInvoiceSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)

    cus_details_str = serializer.validated_data['cus_details']
    ship_details_str = serializer.validated_data['ship_details']
    payment_method = serializer.validated_data['payment_method']

    cart_items = ProductCart.objects.filter(user_id=request.user_id).select_related("product")

    if not cart_items.exists():
        return Response({
            "status": False,
            "message": "Cart is empty"
        }, status=status.HTTP_400_BAD_REQUEST)

    total = 0
    product_names = []

    for item in cart_items:
        total += int(item.qty) * float(item.price)
        product_names.append(item.product.title)

    vat = total * 0.05
    payable = total + vat

    tran_id = f"TXN{request.user_id}{datetime.now().strftime('%Y%m%d%H%M%S')}"

    # payment_status based on method
    if payment_method == "cod":
        pay_status = "unpaid"   # COD => unpaid
    else:
        pay_status = "pending"  # SSL => pending until success callback

    # create invoice first (common for both methods)
    invoice = Invoice.objects.create(
        user_id=request.user_id,
        total=str(total),
        vat=str(vat),
        payable=str(payable),
        cus_details=cus_details_str,
        ship_details=ship_details_str,
        tran_id=tran_id,
        val_id='',
        delivery_status='pending',
        payment_status="unpaid",
        payment_method=payment_method
    )

    # invoice products
    for item in cart_items:
        InvoiceProduct.objects.create(
            invoice_id=invoice.id,
            product_id=item.product_id,
            user_id=request.user_id,
            qty=item.qty,
            sale_price=item.price
        )

    # COD FLOW (NO SSLCommerz call)
    if payment_method == "cod":
        cart_items.delete()  # ✅ clear cart immediately

        return Response({
            "status": True,
            "message": "Order placed successfully (Cash On Delivery)",
            "data": {
                "invoice_id": invoice.id,
                "tran_id": tran_id,
                "total": str(total),
                "vat": str(vat),
                "payable": str(payable),
                "payment_method": "cod"
            }
        }, status=status.HTTP_200_OK)

    # SSL FLOW (payment gateway call)
    try:
        ssl_config = SSLCommerzAccount.objects.first()
        if not ssl_config:
            ssl_config_data = {
                'store_id': 'teamr600c004f8da4d',
                'store_passwd': 'teamr600c004f8da4d@ssl',
                'currency': 'BDT',
                'success_url': 'http://127.0.0.1:8000/PaymentSuccess',
                'fail_url': 'http://127.0.0.1:8000/PaymentFail',
                'cancel_url': 'http://127.0.0.1:8000/PaymentCancel',
                'ipn_url': 'http://127.0.0.1:8000/api/PaymentIPN',
                'init_url': 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php'
            }
        else:
            ssl_config_data = {
                'store_id': ssl_config.store_id,
                'store_passwd': ssl_config.store_passwd,
                'currency': ssl_config.currency,
                'success_url': ssl_config.success_url,
                'fail_url': ssl_config.fail_url,
                'cancel_url': ssl_config.cancel_url,
                'ipn_url': ssl_config.ipn_url,
                'init_url': ssl_config.init_url
            }
    except Exception:
        ssl_config_data = {
            'store_id': 'teamr600c004f8da4d',
            'store_passwd': 'teamr600c004f8da4d@ssl',
            'currency': 'BDT',
            'success_url': 'http://127.0.0.1:8000/PaymentSuccess',
            'fail_url': 'http://127.0.0.1:8000/PaymentFail',
            'cancel_url': 'http://127.0.0.1:8000/PaymentCancel',
            'ipn_url': 'http://127.0.0.1:8000/api/PaymentIPN',
            'init_url': 'https://sandbox.sslcommerz.com/gwprocess/v4/api.php'
        }

    payment_data = {
        'store_id': ssl_config_data['store_id'],
        'store_passwd': ssl_config_data['store_passwd'],
        'total_amount': str(payable),
        'currency': ssl_config_data['currency'],
        'tran_id': tran_id,
        'success_url': ssl_config_data['success_url'],
        'fail_url': ssl_config_data['fail_url'],
        'cancel_url': ssl_config_data['cancel_url'],
        'ipn_url': ssl_config_data['ipn_url'],

        'cus_name': 'Customer',
        'cus_email': request.user_email,
        'cus_add1': cus_details_str,
        'cus_add2': '',
        'cus_city': 'Dhaka',
        'cus_state': 'Dhaka',
        'cus_postcode': '1207',
        'cus_country': 'Bangladesh',
        'cus_phone': '01700000000',
        'cus_fax': '',

        'shipping_method': 'Courier',
        'ship_name': 'Customer',
        'ship_add1': ship_details_str,
        'ship_add2': '',
        'ship_city': 'Dhaka',
        'ship_state': 'Dhaka',
        'ship_country': 'Bangladesh',
        'ship_postcode': '1207',

        'product_name': ', '.join(product_names[:3]) if product_names else 'Products',
        'product_category': 'General',
        'product_profile': 'general',
        'product_amount': str(len(cart_items))
    }

    try:
        response = requests.post(
            ssl_config_data['init_url'],
            data=payment_data,
            timeout=10
        )

        if response.status_code == 200:
            payment_response = response.json()

            if payment_response.get('status') == 'SUCCESS':
                payment_url = payment_response.get('GatewayPageURL', '')

                # ✅ Clear cart after successful payment INIT
                cart_items.delete()

                return Response({
                    "status": True,
                    "message": "Invoice created successfully",
                    "data": {
                        "invoice_id": invoice.id,
                        "tran_id": tran_id,
                        "total": str(total),
                        "vat": str(vat),
                        "payable": str(payable),
                        "payment_method": "sslcommerz",
                        "payment_url": payment_url
                    }
                })
            else:
                return Response({
                    "status": False,
                    "message": "Payment gateway initialization failed",
                    "error": payment_response.get('failedreason', 'Unknown error')
                }, status=status.HTTP_400_BAD_REQUEST)

        return Response({
            "status": False,
            "message": "Failed to connect to payment gateway"
        }, status=status.HTTP_503_SERVICE_UNAVAILABLE)

    except requests.exceptions.Timeout:
        return Response({
            "status": False,
            "message": "Payment gateway timeout"
        }, status=status.HTTP_504_GATEWAY_TIMEOUT)

    except requests.exceptions.RequestException as e:
        return Response({
            "status": False,
            "message": f"Payment gateway error: {str(e)}"
        }, status=status.HTTP_503_SERVICE_UNAVAILABLE)


@api_view(['GET'])
@authentication_classes([JWTAuthentication])
def invoice_list(request):
    """Get user's invoice list with products"""
    invoices = Invoice.objects.filter(user_id=request.user_id).order_by('-created_at')
    data = []
    for invoice in invoices:
        invoice_products = InvoiceProduct.objects.filter(invoice_id=invoice.id).select_related('product')

        products = []
        for item in invoice_products:
            products.append({
                "product_id": item.product.id,
                "product_title": item.product.title,
                "product_image": item.product.image,
                "qty": item.qty,
                "sale_price": item.sale_price
            })

        data.append({
            "invoice_id": invoice.id,
            "tran_id": invoice.tran_id,
            "total": invoice.total,
            "vat": invoice.vat,
            "payable": invoice.payable,
            "cus_details": invoice.cus_details,
            "ship_details": invoice.ship_details,
            "delivery_status": invoice.delivery_status,
            "payment_status": invoice.payment_status,
            "created_at": invoice.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            "products": products
        })

    return Response({
        "status": True,
        "message": "success",
        "data": data
    })


# ============== Payment Callback Endpoints ==============

@api_view(['POST', 'GET'])
@permission_classes([AllowAny])
def payment_success(request):
    """Handle successful payment callback from SSLCommerz"""
    # Get data from POST or GET
    data = request.data if request.method == 'POST' else request.GET.dict()

    tran_id = data.get('tran_id', '')
    val_id = data.get('val_id', '')
    amount = data.get('amount', '')
    card_type = data.get('card_type', '')

    if not tran_id:
        return Response({
            "status": False,
            "message": "Transaction ID not found"
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        invoice = Invoice.objects.get(tran_id=tran_id)
        invoice.payment_status = 'success'
        invoice.val_id = val_id
        invoice.save()

        return Response({
            "status": True,
            "message": "Payment successful",
            "data": {
                "tran_id": tran_id,
                "amount": amount,
                "card_type": card_type
            }
        })
    except Invoice.DoesNotExist:
        return Response({
            "status": False,
            "message": "Invoice not found"
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST', 'GET'])
@permission_classes([AllowAny])
def payment_fail(request):
    """Handle failed payment callback from SSLCommerz"""
    # Get data from POST or GET
    data = request.data if request.method == 'POST' else request.GET.dict()

    tran_id = data.get('tran_id', '')
    error = data.get('error', '')

    if not tran_id:
        return Response({
            "status": False,
            "message": "Transaction ID not found"
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        invoice = Invoice.objects.get(tran_id=tran_id)
        invoice.payment_status = 'failed'
        invoice.save()

        return Response({
            "status": False,
            "message": "Payment failed",
            "error": error
        })
    except Invoice.DoesNotExist:
        return Response({
            "status": False,
            "message": "Invoice not found"
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST', 'GET'])
@permission_classes([AllowAny])
def payment_cancel(request):
    """Handle cancelled payment callback from SSLCommerz"""
    # Get data from POST or GET
    data = request.data if request.method == 'POST' else request.GET.dict()

    tran_id = data.get('tran_id', '')

    if not tran_id:
        return Response({
            "status": False,
            "message": "Transaction ID not found"
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        invoice = Invoice.objects.get(tran_id=tran_id)
        invoice.payment_status = 'cancelled'
        invoice.save()

        return Response({
            "status": False,
            "message": "Payment cancelled"
        })
    except Invoice.DoesNotExist:
        return Response({
            "status": False,
            "message": "Invoice not found"
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
@permission_classes([AllowAny])
def payment_ipn(request):
    """Handle Instant Payment Notification (IPN) from SSLCommerz"""
    data = request.data

    tran_id = data.get('tran_id', '')
    val_id = data.get('val_id', '')
    status_code = data.get('status', '')

    if not tran_id:
        return Response({
            "status": False,
            "message": "Transaction ID not found"
        }, status=status.HTTP_400_BAD_REQUEST)

    try:
        invoice = Invoice.objects.get(tran_id=tran_id)

        if status_code == 'VALID' or status_code == 'VALIDATED':
            invoice.payment_status = 'success'
            invoice.val_id = val_id
        elif status_code == 'FAILED':
            invoice.payment_status = 'failed'
        elif status_code == 'CANCELLED':
            invoice.payment_status = 'cancelled'

        invoice.save()

        return Response({
            "status": True,
            "message": "IPN processed successfully"
        })
    except Invoice.DoesNotExist:
        return Response({
            "status": False,
            "message": "Invoice not found"
        }, status=status.HTTP_404_NOT_FOUND)

@api_view(["GET"])
@authentication_classes([JWTAuthentication])
def my_orders(request):
    invoices = Invoice.objects.filter(user_id=request.user_id).order_by("-id")
    data = InvoiceSerializer(invoices, many=True).data

    return Response({
        "status": True,
        "message": "success",
        "data": data
    })

@api_view(["POST"])
@authentication_classes([JWTAuthentication])
def create_review(request):
    serializer = CreateReviewSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            "status": False,
            "message": "Invalid data",
            "errors": serializer.errors
        }, status=400)

    product_id = serializer.validated_data["product_id"]
    rating = serializer.validated_data["rating"]
    description = serializer.validated_data["description"]

    # must have customer profile
    customer = CustomerProfile.objects.filter(user_id=request.user_id).first()
    if not customer:
        return Response({
            "status": False,
            "message": "Create your profile first"
        }, status=400)

    # product exists?
    product = Product.objects.filter(id=product_id).first()
    if not product:
        return Response({"status": False, "message": "Product not found"}, status=404)

    # user must have a delivered invoice containing this product
    delivered_invoice_ids = Invoice.objects.filter(
        user_id=request.user_id,
        delivery_status="delivered"
    ).values_list("id", flat=True)

    allowed = InvoiceProduct.objects.filter(
        user_id=request.user_id,
        product_id=product_id,
        invoice_id__in=delivered_invoice_ids
    ).exists()

    if not allowed:
        return Response({
            "status": False,
            "message": "You can review only delivered products"
        }, status=403)

    ProductReview.objects.create(
        customer=customer,
        product=product,
        rating=str(rating),
        description=description
    )

    return Response({
        "status": True,
        "message": "Review submitted successfully"
    })

@api_view(["GET"])
@authentication_classes([JWTAuthentication])
def reviewed_products(request):
    """
    Return list of product IDs that the current user already reviewed
    """
    try:
        customer = CustomerProfile.objects.get(user_id=request.user_id)
    except CustomerProfile.DoesNotExist:
        return Response({
            "status": True,
            "data": []
        })

    reviewed_ids = ProductReview.objects.filter(customer=customer).values_list("product_id", flat=True)

    return Response({
        "status": True,
        "data": list(reviewed_ids)
    })

def profile_page(request):
    return render(request, "profile.html")

def product_list(request):
    products = Product.objects.all()
    return render(request, 'product.html', {'products': products})


def cart_page(request):
    return render(request, 'cart.html')


def wish_page(request):
    return render(request, "wishlist.html")

def product_details_page(request):
    return render(request, "product-details.html")

def orders_page(request):
    return render(request, "orders.html")

